SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

CREATE TABLE `course` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `course_name` varchar(255) DEFAULT NULL,
  `int_name` varchar(255) DEFAULT NULL,
  `course_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `course` (`course_name`, `int_name`, `course_id`) VALUES
('Web standards', 'Juan Ponce Enrile', 'ITPC01');

CREATE TABLE `students` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `students` (`name`, `email`, `mobile`) VALUES
('shindy', 'shindy@gmail.com', '19281236472'),
('test5', 'test5@gmail.com', '555555555555'),
('dio', 'dio@email.com', '54345678'),
('gil2', 'gil2@gmail.com', '29384445555'),
('tay', 'tay@email.com', '765456789'),
('wer', 'wer@email.com', '654345678'),
('huy', 'huy@email.com', '234567876543'),
('ref', 'ref@email.com', '3456543113'),
('test3', 'test3@gmail.com', '1224242424'),
('gio57', 'gio57@gmail.com', '097689327887'),
('test4', 'test4@gmail.com', '242143551252');

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `create_datetime` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `users` (`username`, `email`, `password`, `create_datetime`) VALUES
('shaira', 'shaira@gmail.com', '482a53a7536571834cfa06881073227b', '2023-12-12 03:48:13'),
('lee', 'lee@gmail.com', 'b0f8b49f22c718e9924f5b1165111a67', '2023-12-12 03:51:00'),
('shin', 'shin@gmail.com', 'e3a93ca5b9c8954839801fa8b8d1fc87', '2023-12-17 06:19:02');

COMMIT;
