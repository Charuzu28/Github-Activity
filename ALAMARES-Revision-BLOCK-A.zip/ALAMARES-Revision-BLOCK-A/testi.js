//Testimonial Data
const testimonials = [
  {
    name: "Cedric Naño",
    job: "DWCL, Student",
    testimonial: "My cat absolutely loves the toys from CatsEssentials! The quality is fantastic, and they keep my furball entertained for hours.",
  },
  {
    name: "James Ricarte",
    job: "DWCL, Student",
    testimonial:
    "I purchased a cozy bed for my cat, and it's their new favorite spot! CatsEssentials has the best selection of cat products.",
  },
  {
    name: "Mark Joseph Ante",
    job: "DWCL, Student",
    testimonial:
      "Cats Essentials transformed my cat's world! From cozy beds to interactive toys, their products bring endless joy. Highly recommended!",
  },
  
];


let i = 0;
let j = testimonials.length;

let testimonialContainer = document.getElementById("testimonial-container");
let nextBtn = document.getElementById("next");
let prevBtn = document.getElementById("prev");

nextBtn.addEventListener("click", () => {
  i = (j + i + 1) % j;
  displayTestimonial();
});
prevBtn.addEventListener("click", () => {
  i = (j + i - 1) % j;
  displayTestimonial();
});

let displayTestimonial = () => {
  testimonialContainer.innerHTML = `
    <p>${testimonials[i].testimonial}</p>
    <br><br>
    <h3>${testimonials[i].name}</h3>
    <h6>${testimonials[i].job}</h6>
  `;
};
window.onload = displayTestimonial;