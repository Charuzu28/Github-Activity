<?php
require_once "db.php";
include("auth_session.php");

// Fetch departments from the database
$department_query = "SELECT * FROM departments";
$department_result = mysqli_query($conn, $department_query);

if (isset($_POST['save'])) {
    $name = $_POST['course_name'];
    $course_id = $_POST['course_id'];
    $course_description = $_POST['course_description'];
    $department_id = $_POST['department_id'];

    // Check if the department exists in the departments table
    $check_department_query = "SELECT * FROM departments WHERE department_id = '$department_id'";
    $check_department_result = mysqli_query($conn, $check_department_query);

    if (mysqli_num_rows($check_department_result) > 0) {
        // Department exists, proceed with inserting the course
        $sql = "INSERT INTO courses (course_id, course_name,course_description, department_id) VALUES ('$course_id', '$name','$course_description', '$department_id')";
        if (mysqli_query($conn, $sql)) {
            echo '<script>alert("Course has been added.")</script>';
            echo "<script>window.location.href ='dashboard.php'</script>"; // Redirect to dashboard.php
            exit(); // Stop further execution
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }
    } else {
        // Department does not exist, inform the user
        echo "Error: Department with ID '$department_id' does not exist. Please select a valid department ID.";
    }

    mysqli_close($conn);
}
?>


<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <title>Create Course</title>
    <!-- Favicon-->
    <link rel="icon" href="favicon.ico" type="image/x-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,700&subset=latin,cyrillic-ext" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" type="text/css">

    <!-- Bootstrap Core Css -->
    <link href="plugins/bootstrap/css/bootstrap.css" rel="stylesheet">

    <!-- Waves Effect Css -->
    <link href="plugins/node-waves/waves.css" rel="stylesheet" />

    <!-- Animation Css -->
    <link href="plugins/animate-css/animate.css" rel="stylesheet" />

    <!-- Sweet Alert Css -->
    <link href="plugins/sweetalert/sweetalert.css" rel="stylesheet" />

    <!-- Custom Css -->
    <link href="css/style.css" rel="stylesheet">

    <!-- AdminBSB Themes. You can choose a theme from css/themes instead of get all themes -->
    <link href="css/themes/all-themes.css" rel="stylesheet" />
</head>

<body class="theme-black">
    <?php include("nav.php");   ?>


    <section class="content">
        <div class="container-fluid">
            <div class="block-header">
                <h2>COURSE</h2>
            </div>

            <!-- Vertical Layout -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                                ADD COURSE
                            </h2>
                            <ul class="header-dropdown m-r--5">
                                <li class="dropdown">
                                    <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                        <i class="material-icons">more_vert</i>
                                    </a>
                                    <ul class="dropdown-menu pull-right">
                                        <li><a href="javascript:void(0);">Action</a></li>
                                        <li><a href="javascript:void(0);">Another action</a></li>
                                        <li><a href="javascript:void(0);">Something else here</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                        <div class="body">
                            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                                <label for="course_name">Course</label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" id="name" class="form-control" maxlength="50" placeholder="Enter Course name" name="course_name" required>
                                    </div>
                                </div>
                                <label for="course_id">Course ID</label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" id="mobile" class="form-control" maxlength="12" placeholder="Enter the Course ID" name="course_id" required>
                                    </div>
                                </div>
                                <label for="course_description">Course Description</label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" id="mobile" class="form-control" maxlength="12" placeholder="Enter the Course ID" name="course_description" required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="department_id">Department</label>
                                    <div class="form-line">
                                        <select id="department_id" class="form-control" name="department_id" required>
                                            <?php
                                            // Populate dropdown options with departments fetched from the database
                                            while ($row = mysqli_fetch_assoc($department_result)) {
                                                echo "<option value='" . $row['department_id'] . "'>" . $row['department_name'] . "</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <input type="submit" class="btn btn-primary m-t-15 waves-effect" name="save" value="Submit">
                                <a href="dashboard.php" class="btn btn-danger m-t-15 waves-effect">Cancel</a>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #END# Vertical Layout -->
        </div>
    </section>

    <!-- Jquery Core Js -->
    <script src="plugins/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core Js -->
    <script src="plugins/bootstrap/js/bootstrap.js"></script>

    <!-- Select Plugin Js -->
    <script src="plugins/bootstrap-select/js/bootstrap-select.js"></script>

    <!-- Slimscroll Plugin Js -->
    <script src="plugins/jquery-slimscroll/jquery.slimscroll.js"></script>

    <!-- Waves Effect Plugin Js -->
    <script src="plugins/node-waves/waves.js"></script>

    <!-- Custom Js -->
    <script src="js/admin.js"></script>

    <!-- Demo Js -->
    <script src="js/demo.js"></script>
</body>

</html>
