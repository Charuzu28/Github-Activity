<?php
include_once 'db.php';

// Check if ID parameter is set and not empty
if(isset($_GET["id"]) && !empty($_GET["id"])) {
    // Sanitize the ID input
    $id = mysqli_real_escape_string($conn, $_GET["id"]);
    
    // Prepare and execute the delete query
    $sql = "DELETE FROM courses WHERE course_id='$id'";
    if (mysqli_query($conn, $sql)) {
        // If delete operation is successful, redirect to dashboard with a success message
        echo "<script>alert('Course data deleted');</script>"; 
        echo "<script>window.location.href = 'dashboard.php'</script>";     
    } else {
        // If there's an error with the query, display the error message
        echo "Error deleting record: " . mysqli_error($conn);
    }
} else {
    // If ID parameter is not set or empty, display an error message
    echo "<script>alert('No ID provided for deletion.');</script>"; 
    echo "<script>window.location.href = 'dashboard.php'</script>"; 
}

// Close database connection
mysqli_close($conn);
?>
